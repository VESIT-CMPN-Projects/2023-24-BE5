from tkinter import *
from tkinter import messagebox
from PIL import ImageTk, Image

import util

import cv2
import os.path
import pickle
import face_recognition
import datetime

import sounddevice as sd
import soundfile as sf
import librosa
import random

import cvzone
from cvzone.FaceMeshModule import FaceMeshDetector
from cvzone.PlotModule import LivePlot
from test import test
import numpy as np

import os
import json
import time
from smartcard.System import readers
from smartcard.util import toHexString

import ttkbootstrap as tb

# root = Tk()
# root.title("Register")
# root.iconbitmap('@images/vesit.xbm')
# root.geometry("1050x660")


# root.resizable(False, False)
# root['background'] = '#000000'

global placeholder_dob, entry_dob, placeholder_name, entry_name, placeholder_empid, entry_empid, placeholder_pin, \
    entry_pin, name, empid, dob, pin


class App:
    def __init__(self):

        self.card_tap = False
        self.user_name = None
        # self.root = tb.Window(themename="be_project")
        self.root = tb.Window(themename="be_project_light")
        self.root.title("Authentication")
        self.root.geometry("1160x600")

        self.frame1 = tb.LabelFrame(self.root, text="Authentication Steps", labelanchor='n')
        self.frame1.grid(row=1, column=1, padx=50, pady=50)

        # self.label2 = tb.Label(self.frame1, text='Authentication Process', font=('Helvetica Bold', 18),
        #                        bootstyle="dark inverse")
        # self.label2.grid(row=2, column=1, padx=20, pady=15)

        self.root.bind("<Configure>", self.on_window_resize)

        self.label1 = tb.Label(self.root, text='Remote Access Control to Sensitive Areas using Crypto Card',
                               font=('Helvetica Bold', 20))
        self.label1.grid(row=0, column=1, padx=20, pady=20, )

        # buttons

        self.my_style1 = tb.Style()
        self.my_style1.configure("primary.TButton", font=("Helvetica", 18))

        self.my_style2 = tb.Style()
        self.my_style2.configure("success.TButton", font=("Helvetica", 18))

        self.my_style3 = tb.Style()
        self.my_style3.configure("danger.TButton", font=("Helvetica", 18))

        self.button1 = tb.Button(self.frame1, text='Tap the Card', style="primary.TButton", width=18,
                              command=self.tap_card)
        self.button1.grid(row=3, column=1, padx=20, pady=20)

        self.button2 = tb.Button(self.frame1, text='Face', style="primary.TButton", width=18, command=self.face)
        self.button2.grid(row=4, column=1, pady=20, padx=20)

        self.button3 = tb.Button(self.frame1, text='Voice', width=18, command=self.voice, style="primary.TButton")
        self.button3.grid(row=5, column=1, pady=20, padx=20)

        # self.button_register = Button(self.root, text='Register', padx=20, pady=15, font='Helvetica',
        #                               command=self.submit_pd)
        # self.button_register.grid(row=6, column=1, pady=20)

        self.photo1 = Image.open('images/vesit.jpeg')
        self.photo1_resize = self.photo1.resize((100, 100))
        self.new_image1 = ImageTk.PhotoImage(self.photo1_resize)
        self.vesit_logo = Label(self.root, image=self.new_image1)
        self.vesit_logo.grid(row=7, column=2)

        self.photo2 = Image.open('images/tifr-logo.png')
        self.photo2_resize = self.photo2.resize((200, 100))
        self.new_image2 = ImageTk.PhotoImage(self.photo2_resize)
        self.tifr_logo = Label(self.root, image=self.new_image2)
        self.tifr_logo.grid(row=7, column=0)

        self.db_dir = './db'
        if not os.path.exists(self.db_dir):
            os.mkdir(self.db_dir)

        self.log_path = './log.txt'

        self.sampling_rate = 16000
        self.sr = 16000  # Sampling rate
        self.n_mfcc = 13  # Number of MFCC coefficients
        self.n_fft = 512  # FFT window size
        self.hop_length = 256  # Hop length

        # Define the path to the folder containing the .wav files
        self.wav_folder = "wav_files"

        # Define the path to the folder where the pickle files will be saved
        self.pkl_folder = "pkl_files"

        phrases = [
            "The quick brown fox jumps over the lazy dog.",
            "In the middle of difficulty lies opportunity.",
            "Actions speak louder than words.",
            "Life is like a bicycle. To keep your balance, you must keep moving.",
            "Where there is love, there is life.",
            "The only limit to our realization of tomorrow will be our doubts of today.",
            "Don't count the days, make the days count.",
            "Believe you can and you're halfway there.",
            "Success is not final, failure is not fatal: It is the courage to continue that counts.",
            "Happiness is not something ready-made. It comes from your own actions.",
            "Strive not to be a success, but rather to be of value.",
            "The only way to do great work is to love what you do.",
            "In three words I can sum up everything I've learned about life: it goes on.",
            "Be the change that you wish to see in the world.",
            "The best way to predict the future is to create it.",
            "To be yourself in a world that is constantly trying to make you something else is the greatest accomplishment.",
            "The journey of a thousand miles begins with one step.",
            "Do not wait for leaders; do it alone, person to person.",
            "Your time is limited, don't waste it living someone else's life.",
            "The purpose of our lives is to be happy."
        ]
        self.random_phrase = random.choice(phrases)

        self.is_pd = 0
        self.is_face = 0
        self.is_voice = 0

    def on_window_resize(self, event):
        width = event.width
        height = event.height
        print(f"Window resized to {width}x{height}")

    # root.bind("<Configure>", on_window_resize)

    # label1 = Label(root, text='Remote Access Control to Sensitive Areas using Crypto Card', padx=20, pady=20,
    #                font='Helvetica 18 bold')
    # label1.grid(row=0, column=1)

    def submit_pd(self):
        if self.is_pd == 1 and self.is_face == 1 and self.is_voice == 1:
            self.response = messagebox.showinfo('Submitted', 'Your have registered successfully!')
        else:
            messagebox.showwarning("Error", "Please fill out incomplete details")
        if self.response == 'ok':
            self.root.destroy()

    def aes_decrypt_block(self, block, key):
        decrypted_block = bytearray(16)
        for i in range(16):
            decrypted_block[i] = block[i] ^ key[i]
        return bytes(decrypted_block)

    def aes_decrypt(self, data, key):
        decrypted_data = bytearray()
        for i in range(0, len(data), 16):
            block = data[i:i + 16]
            decrypted_block = self.aes_decrypt_block(block, key)
            decrypted_data.extend(decrypted_block)
        return bytes(decrypted_data)

    def card_login(self):
        hash_folder = '/home/drishti/Desktop/review2/sem8_review/CardDetails/hash'
        folder_path = '/home/drishti/Desktop/review2/sem8_review/CardDetails'

        util.msg_box("Connect Card Reader", "Connect card reader and place card on it")
        time.sleep(5)
        # Establish connection with the card reader
        r = readers()
        reader = r[0]
        connection = reader.createConnection()
        connection.connect()
        apdu_command = [0xFF, 0xCA, 0x00, 0x00, 0x00]  # Select command
        response, sw1, sw2 = connection.transmit(apdu_command)
        if sw1 == 0x90 and sw2 == 0x00:
            util.msg_box("Success", "Card details read successfully:")
            self.card_tap = True
        else:
            print("Failed to read card details. Response:", toHexString(response))
        connection.disconnect()
        uid = toHexString(response)  # Convert hexadecimal to string
        hash_mapping_file_path = folder_path + '/hash_mapping.json'
        if not os.path.exists(hash_mapping_file_path):
            print("Hash mapping file not found")
            return

        with open(hash_mapping_file_path, 'r') as hash_mapping_file:
            hash_mapping = json.load(hash_mapping_file)

        hash_value = hash_mapping[uid]
        print(hash_value)

        if uid not in hash_mapping:
            messagebox.showerror("Failure", "Invalid card.")
            return

        reg_mapping_file_path = folder_path + '/reg_mapping.json'
        if not os.path.exists(reg_mapping_file_path):
            print("Reg mapping file not found.")
            return

        with open(reg_mapping_file_path, 'r') as reg_mapping_file:
            reg_mapping = json.load(reg_mapping_file)

        self.user = reg_mapping[hash_value]

        if uid not in hash_mapping:
            messagebox.showerror("Failure", "Invalid card.")
            return

        key_mapping_file_path = folder_path + '/key_mapping.json'
        if not os.path.exists(key_mapping_file_path):
            messagebox.showwarning("User not found", "User-key mapping file not found.")
            return

        with open(key_mapping_file_path, 'r') as key_mapping_file:
            self.user_keys = json.load(key_mapping_file)

        # Check if user exists in the mappings
        if self.user not in self.user_keys:
            messagebox.showwarning("User not found", "User not found.")
            return

    def validate_card(self, pin):
        # self.user_name = name.get()
        # self.user_empid = empid.get()
        # self.user_dob = dob.get()
        self.user_pin = pin.get()
        self.face_file_name = ''
        if len(self.user_pin) == 0:
            messagebox.showwarning('Error', 'Please fill out the data')
        elif self.card_tap:
            consecutive_attempts = 0
            stored_key = self.user_keys[self.user]
            while consecutive_attempts < 3:  # Check if consecutive attempts are less than 3
                # Prompt the user to enter custom key
                print('Welcome ', self.user.upper(), ':')
                self.entry_pin.delete(0, END)
                pin = StringVar()
                self.entry_pin = tb.Entry(top1, textvariable=pin, show='*', font=("Helvetica", 18))
                self.entry_pin.pack(padx=20, pady=20)
                # print('Enter custom key: ')
                # custom_key = input()

                # Check if the entered key matches the stored key
                if self.user_pin != stored_key:
                    consecutive_attempts += 1  # Increment consecutive invalid attempts counter
                    messagebox.showwarning("Invalid key", "Attempt {} of 3".format(consecutive_attempts))
                    if consecutive_attempts == 3:
                        messagebox.showerror("Failure", "Too many consecutive invalid attempts. User is blocked.")

                        return
                else:
                    # Reset consecutive invalid attempts counter on successful login
                    print("Correct key entered.")
                    consecutive_attempts = 0

                    # Convert the custom key to bytes
                    custom_key_bytes = self.user_pin.encode()

                    # Ensure the key is exactly 16 bytes by padding or truncating it
                    if len(custom_key_bytes) < 16:
                        custom_key_bytes += b'\x00' * (16 - len(custom_key_bytes))
                    elif len(custom_key_bytes) > 16:
                        custom_key_bytes = custom_key_bytes[:16]

                    # Encrypted image and audio pickle file paths
                    # encrypted_image_pickle_file_path = f'C:\\Users\\Figo Cardozo\\Downloads\\Card Verification\\Card Verification\\encrypted_image_pkl\\en_i_{user}.pickle'
                    # encrypted_audio_pickle_file_path = f'C:\\Users\\Figo Cardozo\\Downloads\\Card Verification\\Card Verification\\encrypted_audio_pkl\\en_a_{user}.pkl'
                    encrypted_image_pickle_file_path = f'/home/drishti/Desktop/review2/sem8_review/CardDetails/encrypted_image_pkl/en_i_{self.user}.pickle'
                    encrypted_audio_pickle_file_path = f'/home/drishti/Desktop/review2/sem8_review/CardDetails/encrypted_audio_pkl/en_a_{self.user}.pkl'

                    # Read the encrypted image and audio pickle files
                    with open(encrypted_image_pickle_file_path, "rb") as encrypted_image_pickle_file:
                        encrypted_image_data = encrypted_image_pickle_file.read()

                    with open(encrypted_audio_pickle_file_path, "rb") as encrypted_audio_pickle_file:
                        encrypted_audio_data = encrypted_audio_pickle_file.read()

                    # Decrypt the image and audio data separately
                    decrypted_image_data = self.aes_decrypt(encrypted_image_data, custom_key_bytes)
                    decrypted_audio_data = self.aes_decrypt(encrypted_audio_data, custom_key_bytes)

                    # Paths for saving decrypted files
                    # de_i_path = 'C:\\Users\\Figo Cardozo\\Downloads\\Card Verification\\Card Verification\\decrypted_image_pkl'
                    # de_a_path = 'C:\\Users\\Figo Cardozo\\Downloads\\Card Verification\\Card Verification\\decrypted_audio_pkl'

                    de_i_path = '/home/drishti/Desktop/review2/sem8_review/CardDetails/decrypted_image_pkl'
                    de_a_path = '/home/drishti/Desktop/review2/sem8_review/CardDetails/decrypted_audio_pkl'

                    if not os.path.exists(de_i_path):
                        os.makedirs(de_i_path)

                    if not os.path.exists(de_a_path):
                        os.makedirs(de_a_path)

                    # Save the decrypted image pickle file
                    decrypted_image_pickle_file_path = f'/home/drishti/Desktop/review2/sem8_review/CardDetails/decrypted_image_pkl/de_i_{self.user}.pickle'
                    with open(decrypted_image_pickle_file_path, "wb") as decrypted_image_pickle_file:
                        decrypted_image_pickle_file.write(decrypted_image_data)

                    # Save the decrypted audio pickle file
                    decrypted_audio_pickle_file_path = f'/home/drishti/Desktop/review2/sem8_review/CardDetails/decrypted_audio_pkl/de_a_{self.user}.pkl'
                    with open(decrypted_audio_pickle_file_path, "wb") as decrypted_audio_pickle_file:
                        decrypted_audio_pickle_file.write(decrypted_audio_data)

                    print("Decrypted files saved successfully!")
                    util.msg_box("Success", "kindly proceed for face authentication")
                    top1.destroy()
                    self.is_pd = 1
                    return
        else:
            messagebox.showwarning("Try again", 'Please tap the card first')

    def tap_card(self):
        if self.is_pd == 0:
            global top1
            top1 = Toplevel()
            top1.title('Tap the Card')
            top1.geometry("600x290")
            top1.configure(background="#d9e3f8")

            label_connect = tb.Button(top1, text='Tap your Card', style="primary.TButton", width=18, command=self.card_login)
            # label_connect.grid(row=0, column=0, padx=20, pady=20)
            label_connect.pack(padx=20, pady=30)
            label_pin = tb.Label(top1, text='Enter your PIN: ', bootstyle="bg", font=("Helvetica", 18))
            # label_pin.grid(row=1, column=0, padx=20, pady=20)
            label_pin.pack(padx=20, pady=10)
            pin = StringVar()
            global placeholder_pin, entry_pin
            self.entry_pin = tb.Entry(top1, textvariable=pin, show='*', font=("Helvetica", 18))
            # self.entry_pin.grid(row=1, column=1, padx=20, pady=20)
            self.entry_pin.pack(padx=20, pady=20)
            # placeholder_pin = 'Enter your PIN'
            # entry_pin.insert(0, placeholder_pin)
            # entry_pin.bind("<FocusIn>", on_entry_focus_pin)

            # button_submit = Button(top1, text='Submit', command=top1.destroy)
            # button_submit.grid(row=5, column=1)
            button_submit = tb.Button(top1, text='Submit', style="success.TButton", command=lambda: self.validate_card(pin))
            # button_submit.grid(row=4, column=1)
            button_submit.pack()
        else:
            messagebox.showwarning("Error", "You have already filled out these details once")

    def add_webcam(self, label):
        if 'cap' not in self.__dict__:
            self.cap = cv2.VideoCapture(0)

        self._label = label
        self.process_webcam()

    def process_webcam(self):
        ret, frame = self.cap.read()

        self.most_recent_capture_arr = frame
        img_ = cv2.cvtColor(self.most_recent_capture_arr, cv2.COLOR_BGR2RGB)
        self.most_recent_capture_pil = Image.fromarray(img_)
        imgtk = ImageTk.PhotoImage(image=self.most_recent_capture_pil)
        self._label.imgtk = imgtk
        self._label.configure(image=imgtk)

        self._label.after(20, self.process_webcam)

    def face(self):
        if self.is_pd == 1 and self.is_face == 0:

            self.top2 = Toplevel()
            self.top2.title('Face')
            self.top2.geometry("1000x520+350+100")
            self.top2.configure(background="#d9e3f8")

            webcam_label = util.get_img_label(self.top2)
            webcam_label.place(x=10, y=0, width=700, height=500)

            self.add_webcam(webcam_label)

            # frame2 = Frame(top2, background='lightgreen', padx=175, pady=100)
            # frame2.grid(row=0, column=0, columnspan=3, padx=20, pady=20)
            # Label(frame2, text="Face").grid()

            self.login_button_main_window = tb.Button(self.top2, text='Authenticate', style="primary.TButton", width=18, command=self.login)
            self.login_button_main_window.place(x=725, y=225)

            # self.register_new_user_button_main_window = util.get_button(self.top2, 'Submit', 'black',
            #                                                             self.close_cam)
            # self.register_new_user_button_main_window.place(x=750, y=300)

        elif self.is_pd == 0:
            messagebox.showwarning("Error", "Please enter your Personal Details")

        elif self.is_face != 0:
            messagebox.showwarning("Error", "You have already filled out these details once")

    def login(self):

        label = test(
            image=self.most_recent_capture_arr,
            model_dir='/home/drishti/Desktop/review2/sem8_review/resources/anti_spoof_models/',
            device_id=0
        )

        if label == 1:

            name_f = util.recognize(self.most_recent_capture_arr, self.db_dir)

            if name_f in ['unknown_person', 'no_persons_found']:
                util.msg_box('Oops...', 'Unknown user. Please register new user or try again.')
            else:
                detector = FaceMeshDetector(maxFaces=1)
                plotY = LivePlot(640, 360, [20, 50], invert=True)

                ratioList = []
                blinkCounter = 0
                counter = 0
                color = (255, 0, 255)
                actualBlink = random.randint(3, 5)

                while blinkCounter != actualBlink:

                    if self.cap.get(cv2.CAP_PROP_POS_FRAMES) == self.cap.get(cv2.CAP_PROP_FRAME_COUNT):
                        self.cap.set(cv2.CAP_PROP_POS_FRAMES, 0)

                    success, img = self.cap.read()
                    img, faces = detector.findFaceMesh(img, draw=False)

                    if faces:
                        face = faces[0]

                        leftUp = face[159]
                        leftDown = face[23]
                        leftLeft = face[130]
                        leftRight = face[243]
                        lengthVer, _ = detector.findDistance(leftUp, leftDown)
                        lengthHour, _ = detector.findDistance(leftLeft, leftRight)

                        ratio = int((lengthVer / lengthHour) * 100)
                        ratioList.append(ratio)
                        if len(ratioList) > 3:
                            ratioList.pop(0)
                        ratioAvg = sum(ratioList) / len(ratioList)

                        if ratioAvg < 35 and counter == 0:
                            blinkCounter += 1
                            color = (0, 200, 0)
                            counter = 1
                        if counter != 0:
                            counter += 1
                            if counter > 10:
                                counter = 0
                                color = (255, 0, 255)

                        cvzone.putTextRect(img, f'Blink Count: {blinkCounter}', (100, 150),
                                           colorR=color)
                        cvzone.putTextRect(img, f'Blink your eyes {actualBlink} times', (50, 100),
                                           colorR=color)

                        imgPlot = plotY.update(ratioAvg, color)
                        img = cv2.resize(img, (640, 360))
                        imgStack = cvzone.stackImages([img, imgPlot], 2, 1)

                    else:
                        img = cv2.resize(img, (640, 360))
                        imgStack = cvzone.stackImages([img, img], 2, 1)

                    cv2.imshow("Image", imgStack)
                    cv2.waitKey(25)
                util.msg_box('Welcome, {}.'.format(name_f), 'Kindly proceed for voice authentication')
                self.name_f = name_f

                with open(self.log_path, 'a') as f:
                    f.write('{},{},in\n'.format(name_f, datetime.datetime.now()))
                    f.close()
                self.is_face = 1
                self.cap.release()
                cv2.destroyWindow("Image")
                self.top2.destroy()

        else:
            print("error")
            # util.msg_box('No person detected!', 'This is an image, and not a person !')

    def voice(self):
        if self.is_face == 1 and self.is_voice == 0:
            self.top3 = Toplevel()
            self.top3.title('Voice')
            self.top3.geometry("1000x300")
            self.top3.configure(background="#d9e3f8")

            label3 = tb.Label(self.top3, text='Please say the phrase given below', bootstyle="bg",
                           font=('Helvetica', 18))
            label3.pack(padx=20, pady=15)

            self.label_phrase = tb.Label(self.top3, text=self.random_phrase, bootstyle="bg", font=('Helvetica', 18))
            self.label_phrase.pack(pady=20, padx=20)

            button_record = tb.Button(self.top3, text='Record', command=self.login_speaker, style="primary.TButton")
            button_record.pack(padx=22, pady=15)

            # button_submit = Button(self.top3, text='Submit', padx=20, pady=18, command=self.verify_voice)
            # button_submit.pack(pady=10)
        elif self.is_face == 0:
            messagebox.showwarning("Error", "Please capture your Face")

        elif self.is_voice != 0:
            messagebox.showwarning("Error", "You have already filled out these details once")

    def login_speaker(self):
        # Record the user's voice and save it as a .wav file
        wav_file = "login.wav"
        self.record(wav_file)
        # Convert the .wav file to a pickle file
        pkl_file = "login.pkl"
        self.wav_to_pkl(wav_file, pkl_file)
        # Load the MFCC features from the pickle file
        login_mfcc = self.load_mfcc(pkl_file)
        # Initialize an empty list to store the cosine similarities
        cos_sims = []
        # Loop through each registered speaker
        for speaker in os.listdir(self.pkl_folder):
            # Skip the login pickle file
            if speaker == "login.pkl":
                # print(f"Skipping {speaker}")
                continue
            # print(f"Comparing with {speaker}")
            # Load the MFCC features from the speaker's pickle file
            speaker_mfcc = self.load_mfcc(os.path.join(self.pkl_folder, speaker))
            # Compute the cosine similarity between the login MFCC and the speaker MFCC
            cos_sim = self.cosine_similarity(login_mfcc, speaker_mfcc)
            # Append the cosine similarity to the list
            cos_sims.append((speaker, cos_sim))  # Append both speaker name and cosine similarity
        # Find the speaker with the maximum cosine similarity
        max_speaker, max_cos_sim = max(cos_sims, key=lambda x: x[1])
        max_name = os.path.splitext(max_speaker)[0]
        # Return the name of the speaker with maximum similarity
        if max_name.lower() == self.name_f.lower():
            util.msg_box('Success', f'Access Granted to {max_name}')
            exit()
        else:
            messagebox.showerror('Fail', f'Access Denied')
            exit()

    def cosine_similarity(self, mfcc1, mfcc2):
        # Ensure both MFCC vectors have the same shape
        if mfcc1.shape != mfcc2.shape:
            raise ValueError("MFCC vectors must have the same shape for cosine similarity calculation.")

        # Flatten the MFCC features to 1D vectors
        mfcc1 = mfcc1.flatten()
        mfcc2 = mfcc2.flatten()

        # Compute the dot product between the two vectors
        dot_product = np.dot(mfcc1, mfcc2)

        # Compute the norm of each vector
        norm1 = np.linalg.norm(mfcc1)
        norm2 = np.linalg.norm(mfcc2)

        # Compute the cosine similarity
        cos_sim = dot_product / (norm1 * norm2)

        # Return the cosine similarity
        return cos_sim

    def verify_voice(self):
        # if len(self.pkl_file) != 0:
        #     self.is_voice = 1
        self.top3.destroy()

    def load_mfcc(self, pkl_file):
        # Load the MFCCs from the pickle file
        with open(pkl_file, "rb") as f:
            mfcc = pickle.load(f)
        # Return the MFCCs as a numpy array
        return np.array(mfcc)

    def record(self, output_file, duration=5, wav_folder="wav_files", pkl_folder="pkl_files"):
        print(f"Recording... Please speak for {duration} seconds.")
        audio_data = sd.rec(int(duration * self.sampling_rate), samplerate=self.sampling_rate, channels=1,
                            dtype='int16')
        sd.wait()

        # Save the .wav file in the specified folder
        wav_path = os.path.join(wav_folder, output_file)
        sf.write(wav_path, audio_data, self.sampling_rate)
        sf.write(output_file, audio_data, self.sampling_rate)
        print(f"Recording saved to {wav_path}")

    def wav_to_pkl(self, wav_file, pkl_file):
        # Load the audio data from the .wav file
        audio_data, _ = librosa.load(wav_file, sr=self.sr)
        # Compute the MFCCs for the audio data
        mfcc = librosa.feature.mfcc(y=audio_data, sr=self.sr, n_mfcc=self.n_mfcc, n_fft=self.n_fft,
                                    hop_length=self.hop_length)
        print(mfcc)

        # Save the MFCCs as a pickle file
        with open(pkl_file, "wb") as f:
            pickle.dump(mfcc, f)

    def record_voice(self):
        wav_file = self.name_f + ".wav"
        self.record(wav_file)

    def start(self):
        self.root.mainloop()


if __name__ == "__main__":
    app = App()
    app.start()
