# Import the required libraries
import pickle
import librosa
import numpy as np
import sklearn
import os

import sounddevice as sd
import soundfile as sf

class VoiceRecorder:
    def __init__(self, sampling_rate=16000):
        self.sampling_rate = sampling_rate

    def record(self, output_file, duration=5, wav_folder="wav_files", pkl_folder="pkl_files"):
        print(f"Recording... Please speak for {duration} seconds.")
        audio_data = sd.rec(int(duration * self.sampling_rate), samplerate=self.sampling_rate, channels=1, dtype='int16')
        print(audio_data)
        sd.wait()

        # Save the .wav file in the specified folder
        wav_path = os.path.join(wav_folder, output_file)
        sf.write(wav_path, audio_data, self.sampling_rate)
        sf.write(output_file, audio_data, self.sampling_rate)
        print(f"Recording saved to {wav_path}")

        # Convert the .wav file to a pickle file and save it in the pkl_files folder
        pkl_file = os.path.join(pkl_folder, os.path.splitext(output_file)[0] + ".pkl")
        wav_to_pkl(wav_path, pkl_file)
        print(f"Pickle file saved to {pkl_file}")

voice_recorder = VoiceRecorder()


class VR:
    def __init__(self, sampling_rate=16000):
        self.sampling_rate = sampling_rate

    def record(self, output_file, duration=5, wav_folder="wav_files", pkl_folder="pkl_files"):
        print(f"Recording... Please speak for {duration} seconds.")
        audio_data = sd.rec(int(duration * self.sampling_rate), samplerate=self.sampling_rate, channels=1, dtype='int16')
        sd.wait()

        # Save the .wav file in the specified folder
        wav_path = os.path.join(wav_folder, output_file)
        sf.write(wav_path, audio_data, self.sampling_rate)
        sf.write(output_file, audio_data, self.sampling_rate)
        print(f"Recording saved to {wav_path}")

        # Convert the .wav file to a pickle file and save it in the pkl_files folder
        #pkl_file = os.path.join(pkl_folder, os.path.splitext(output_file)[0] + ".pkl")
        #wav_to_pkl(wav_path, pkl_file)
        #print(f"Pickle file saved to {pkl_file}")

v_r = VR()


# Define the parameters for MFCC extraction
sr = 16000 # Sampling rate
n_mfcc = 13 # Number of MFCC coefficients
n_fft = 512 # FFT window size
hop_length = 256 # Hop length

# Define the path to the folder containing the .wav files
wav_folder = "wav_files"

# Define the path to the folder where the pickle files will be saved
pkl_folder = "pkl_files"

# Define a function to convert a .wav file to a pickle file
def wav_to_pkl(wav_file, pkl_file):
    # Load the audio data from the .wav file
    audio_data, _ = librosa.load(wav_file, sr=sr)
    # Compute the MFCCs for the audio data
    mfcc = librosa.feature.mfcc(y=audio_data, sr=sr, n_mfcc=n_mfcc, n_fft=n_fft, hop_length=hop_length)
    print(mfcc)

    # Save the MFCCs as a pickle file
    with open(pkl_file, "wb") as f:
        pickle.dump(mfcc, f)

# Loop through each .wav file in the folder
for wav_file in os.listdir(wav_folder):
    # Get the file name without the extension
    file_name = os.path.splitext(wav_file)[0]
    # Construct the path to the .wav file
    wav_path = os.path.join(wav_folder, wav_file)
    # Construct the path to the pickle file
    pkl_path = os.path.join(pkl_folder, file_name + ".pkl")
    # Convert the .wav file to a pickle file
    wav_to_pkl(wav_path, pkl_path)

# Define a function to load the MFCC features from a pickle file
def load_mfcc(pkl_file):
    # Load the MFCCs from the pickle file
    with open(pkl_file, "rb") as f:
        mfcc = pickle.load(f)
    # Return the MFCCs as a numpy array
    return np.array(mfcc)

# Define a function to compute the cosine similarity between two MFCC features
def cosine_similarity(mfcc1, mfcc2):
    # Ensure both MFCC vectors have the same shape
    if mfcc1.shape != mfcc2.shape:
        raise ValueError("MFCC vectors must have the same shape for cosine similarity calculation.")

    # Flatten the MFCC features to 1D vectors
    mfcc1 = mfcc1.flatten()
    mfcc2 = mfcc2.flatten()

    # Compute the dot product between the two vectors
    dot_product = np.dot(mfcc1, mfcc2)

    # Compute the norm of each vector
    norm1 = np.linalg.norm(mfcc1)
    norm2 = np.linalg.norm(mfcc2)

    # Compute the cosine similarity
    cos_sim = dot_product / (norm1 * norm2)

    # Return the cosine similarity
    return cos_sim

# Define a function to register a speaker by asking for their name and recording their voice
def register_speaker():
    # Ask the user to enter their name
    name = input("Please enter your name: ")
    # Record the user's voice and save it as a .wav file
    wav_file = name + ".wav"
    voice_recorder.record(wav_file)
    # Convert the .wav file to a pickle file
    pkl_file = name + ".pkl"
    wav_to_pkl(wav_file, pkl_file)
    # Return the name and the pickle file
    return name, pkl_file


def login_speaker():
    # Record the user's voice and save it as a .wav file
    wav_file = "login.wav"
    v_r.record(wav_file)
    # Convert the .wav file to a pickle file
    pkl_file = "login.pkl"
    wav_to_pkl(wav_file, pkl_file)
    # Load the MFCC features from the pickle file
    login_mfcc = load_mfcc(pkl_file)
    # Initialize an empty list to store the cosine similarities
    cos_sims = []
    # Loop through each registered speaker
    for speaker in os.listdir(pkl_folder):
        # Skip the login pickle file
        if speaker == "login.pkl":
            # print(f"Skipping {speaker}")
            continue
        # print(f"Comparing with {speaker}")
        # Load the MFCC features from the speaker's pickle file
        speaker_mfcc = load_mfcc(os.path.join(pkl_folder, speaker))
        # Compute the cosine similarity between the login MFCC and the speaker MFCC
        cos_sim = cosine_similarity(login_mfcc, speaker_mfcc)
        # Append the cosine similarity to the list
        cos_sims.append((speaker, cos_sim))  # Append both speaker name and cosine similarity
    # Find the speaker with the maximum cosine similarity
    max_speaker, max_cos_sim = max(cos_sims, key=lambda x: x[1])
    max_name = os.path.splitext(max_speaker)[0]
    # Return the name of the speaker with maximum similarity
    return max_name

# Register some speakers

def main():
    while True:
        print("Welcome to the voice authentication system!")
        print("1. Register")
        print("2. Log in")
        print("3. Exit")
        choice = input("Enter your choice: ")
        if choice == "1":
            speaker1, pkl1 = register_speaker()
            print("Registration complete.")
        elif choice == "2":
            print("Logging in a speaker...")
            login_name = login_speaker()
            print("The speaker is " + login_name)
        elif choice == "3":
            exit()

if __name__ == "__main__":
    main()

