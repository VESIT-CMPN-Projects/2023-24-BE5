from tkinter import *
from tkinter import messagebox
from PIL import ImageTk, Image

root = Tk()
root.title('Login')
root.geometry('1050x565')

global placeholder_pin, entry_pin


def on_window_resize(event):
    width = event.width
    height = event.height
    print(f"Window resized to {width}x{height}")


def on_entry_focus_pin(event):
    if entry_pin.get() == placeholder_pin:
        entry_pin.delete(0, END)


def record():
    response = messagebox.showinfo('Submitted', 'Access Granted!')
    if response == 'ok':
        root.destroy()


def tap_card():
    top1 = Toplevel()
    top1.title('Tap the Card')
    top1.geometry("300x100")

    label_pin = Label(top1, text='PIN: ', padx=20, pady=20)
    label_pin.grid(row=0, column=0)
    pin = StringVar()
    global placeholder_pin, entry_pin
    entry_pin = Entry(top1, textvariable=pin, show='*')
    entry_pin.grid(row=0, column=1, padx=20, pady=20)
    placeholder_pin = 'Enter your PIN'
    entry_pin.insert(0, placeholder_pin)
    entry_pin.bind("<FocusIn>", on_entry_focus_pin)

    button_submit = Button(top1, text='Submit', command=top1.destroy)
    button_submit.grid(row=4, column=1)


def face():
    top2 = Toplevel()
    top2.title('Face')
    top2.geometry("420x370")

    frame2 = Frame(top2, background='lightgreen', padx=175, pady=100)
    frame2.grid(row=0, column=0, columnspan=3, padx=20, pady=20)
    Label(frame2, text="Face").grid()

    button_submit = Button(top2, text='Authenticate', padx=69, pady=20, command=top2.destroy)
    button_submit.grid(row=2, column=1, pady=10)


def voice():
    top3 = Toplevel()
    top3.title('Voice')
    top3.geometry("550x300")

    label3 = Label(top3, text='Please say the phrase given below to record your voice', padx=20, pady=15,
                   font='Helvetica 15 bold')
    label3.pack(pady=10)

    label_phrase = Label(top3, text='some phrase will be displayed here', pady=20, padx=20, bg='lightgreen')
    label_phrase.pack(pady=10)

    button_record = Button(top3, text='Record', padx=22, pady=15, command=record)
    button_record.pack(pady=10)


root.bind("<Configure>", on_window_resize)

label1 = Label(root, text='Remote Access Control to Sensitive Areas using Crypto Card', padx=20, pady=20,
               font='Helvetica 18 bold')
label1.grid(row=0, column=1)

frame1 = Frame(root, background='lightgreen', padx=50, pady=50)
frame1.grid(row=1, column=1)

label2 = Label(frame1, text='Login Steps', padx=20, pady=15, font='Helvetica 15 bold')
label2.grid(row=2, column=1, pady=10)

# buttons
button1 = Button(frame1, text='Tap the Card', padx=33, pady=15, font='Helvetica', command=tap_card)
button1.grid(row=3, column=1, pady=10)

button2 = Button(frame1, text='Face', padx=61, pady=15, font='Helvetica', command=face)
button2.grid(row=4, column=1, pady=10)

button3 = Button(frame1, text='Voice', padx=59, pady=15, font='Helvetica', command=voice)
button3.grid(row=5, column=1, pady=10)

# button_register = Button(root, text='Login', padx=20, pady=15, font='Helvetica', command=submit_pd)
# button_register.grid(row=6, column=1, pady=20)


photo1 = Image.open('images/vesit.jpeg')
photo1_resize = photo1.resize((100, 100))
new_image1 = ImageTk.PhotoImage(photo1_resize)
vesit_logo = Label(root, image=new_image1)
vesit_logo.grid(row=7, column=2)

photo2 = Image.open('images/tifr-logo.png')
photo2_resize = photo2.resize((200, 100))
new_image2 = ImageTk.PhotoImage(photo2_resize)
tifr_logo = Label(root, image=new_image2)
tifr_logo.grid(row=7, column=0)

root.mainloop()
