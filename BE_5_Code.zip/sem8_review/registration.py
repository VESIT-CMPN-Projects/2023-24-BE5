from tkinter import *
from tkinter import messagebox
from PIL import ImageTk, Image

import util

import cv2
import os.path
import pickle
import face_recognition

import sounddevice as sd
import soundfile as sf
import librosa
import random

import json
import hashlib
from smartcard.System import readers
from smartcard.util import toHexString
import time

import ttkbootstrap as tb
from tkinter import ttk

# root = Tk()
# root.title("Register")
# root.iconbitmap('@images/vesit.xbm')
# root.geometry("1050x660")


# root.resizable(False, False)
# root['background'] = '#000000'

global placeholder_dob, entry_dob, placeholder_name, entry_name, placeholder_empid, entry_empid, placeholder_pin, \
    entry_pin, name, empid, dob, pin


class App:
    def __init__(self):
        # self.root = tb.Window(themename="be_project")
        self.root = tb.Window(themename="be_project_light")
        self.root.title("Register")
        self.root.geometry("1165x630")

        # style = ttk.Style(self.root)
        # style.configure('n.TLabelFrame', labelanchor='n', font=("Helvetica", 18), bordercolor="border")

        self.my_style4 = tb.Style()
        self.my_style4.configure("n.TLabelframe", font=("Helvetica", 18))

        self.frame1 = tb.LabelFrame(self.root, border=5, text="Registration Steps", labelanchor="n", style="n.TLabelframe")
        self.frame1.grid(row=1, column=1, padx=50, pady=50)

        # self.label2 = tb.Label(self.frame1, text='Registration Process', bootstyle="bg",
        #                        font=('Helvetica Bold', 18))
        # self.label2.grid(row=2, column=1, padx=20, pady=15)

        self.root.bind("<Configure>", self.on_window_resize)

        self.label1 = tb.Label(self.root, text='Remote Access Control to Sensitive Areas using Crypto Card',
                               font=('Helvetica Bold', 20))
        self.label1.grid(row=0, column=1, padx=20, pady=20)

        # buttons

        self.my_style1 = tb.Style()
        self.my_style1.configure("primary.TButton", font=("Helvetica", 18))

        self.my_style2 = tb.Style()
        self.my_style2.configure("success.TButton", font=("Helvetica", 18))

        self.my_style3 = tb.Style()
        self.my_style3.configure("danger.TButton", font=("Helvetica", 18))

        self.button1 = tb.Button(self.frame1, text='Personal Details', style="primary.TButton",
                                 command=self.personal_details, width=18)
        self.button1.grid(row=3, column=1, padx=20, pady=20)

        self.button2 = tb.Button(self.frame1, text='Face', width=18, style="primary.TButton", command=self.face)
        self.button2.grid(row=4, column=1, padx=20, pady=20)

        self.button3 = tb.Button(self.frame1, text='Voice', width=18, style="primary.TButton", command=self.voice)
        self.button3.grid(row=5, column=1, padx=20, pady=20)

        self.button_register = tb.Button(self.root, text='Register', width=21, style="success.TButton",
                                         command=self.submit_pd)
        self.button_register.grid(row=6, column=1, padx=20)

        self.photo1 = Image.open('images/vesit.jpeg')
        self.photo1_resize = self.photo1.resize((100, 100))
        self.new_image1 = ImageTk.PhotoImage(self.photo1_resize)
        self.vesit_logo = Label(self.root, image=self.new_image1)
        self.vesit_logo.grid(row=7, column=2)

        self.photo2 = Image.open('images/tifr-logo.png')
        self.photo2_resize = self.photo2.resize((200, 100))
        self.new_image2 = ImageTk.PhotoImage(self.photo2_resize)
        self.tifr_logo = Label(self.root, image=self.new_image2)
        self.tifr_logo.grid(row=7, column=0)

        self.db_dir = './db'
        if not os.path.exists(self.db_dir):
            os.mkdir(self.db_dir)

        self.sampling_rate = 16000
        self.sr = 16000  # Sampling rate
        self.n_mfcc = 13  # Number of MFCC coefficients
        self.n_fft = 512  # FFT window size
        self.hop_length = 256  # Hop length

        # Define the path to the folder containing the .wav files
        self.wav_folder = "wav_files"

        # Define the path to the folder where the pickle files will be saved
        self.pkl_folder = "pkl_files"

        self.access = False

        phrases = [
            "The quick brown fox jumps over the lazy dog.",
            "In the middle of difficulty lies opportunity.",
            "Actions speak louder than words.",
            "Life is like a bicycle. To keep your balance, you must keep moving.",
            "Where there is love, there is life.",
            "The only limit to our realization of tomorrow will be our doubts of today.",
            "Don't count the days, make the days count.",
            "Believe you can and you're halfway there.",
            "Success is not final, failure is not fatal: It is the courage to continue that counts.",
            "Happiness is not something ready-made. It comes from your own actions.",
            "Strive not to be a success, but rather to be of value.",
            "The only way to do great work is to love what you do.",
            "In three words I can sum up everything I've learned about life: it goes on.",
            "Be the change that you wish to see in the world.",
            "The best way to predict the future is to create it.",
            "To be yourself in a world that is constantly trying to make you something else is the greatest accomplishment.",
            "The journey of a thousand miles begins with one step.",
            "Do not wait for leaders; do it alone, person to person.",
            "Your time is limited, don't waste it living someone else's life.",
            "The purpose of our lives is to be happy."
        ]
        self.random_phrase = random.choice(phrases)

        self.is_pd = 0
        self.is_face = 0
        self.is_voice = 0

    def on_window_resize(self, event):
        width = event.width
        height = event.height
        print(f"Window resized to {width}x{height}")

    # root.bind("<Configure>", on_window_resize)

    # label1 = Label(root, text='Remote Access Control to Sensitive Areas using Crypto Card', padx=20, pady=20,
    #                font='Helvetica 18 bold')
    # label1.grid(row=0, column=1)

    def aes_encrypt_block(self, block, key):
        encrypted_block = bytearray(16)
        for i in range(16):
            encrypted_block[i] = block[i] ^ key[i]
        return bytes(encrypted_block)

    def aes_encrypt(self, data, key):
        encrypted_data = bytearray()
        for i in range(0, len(data), 16):
            block = data[i:i + 16]
            encrypted_block = self.aes_encrypt_block(block, key)
            encrypted_data.extend(encrypted_block)
        return bytes(encrypted_data)

    def calculate_sha256(self, data):
        hash_object = hashlib.sha256()
        hash_object.update(data)
        return hash_object.hexdigest()

    def card_details(self):
        self.folder_path = '/home/drishti/Desktop/review2/sem8_review/CardDetails'
        self.hash_path = '/home/drishti/Desktop/review2/sem8_review/CardDetails/hash'
        en_i_path = '/home/drishti/Desktop/review2/sem8_review/CardDetails/encrypted_image_pkl'
        en_a_path = '/home/drishti/Desktop/review2/sem8_review/CardDetails/encrypted_audio_pkl'

        self.user_keys = {self.user_name: self.user_pin}
        key_mapping_file_path = self.folder_path + '/key_mapping.json'
        if os.path.exists(key_mapping_file_path):
            # If the file exists, load existing data
            with open(key_mapping_file_path, 'r') as key_mapping_file:
                existing_data = json.load(key_mapping_file)
        else:
            # If the file doesn't exist, create an empty dictionary
            existing_data = {}

        existing_data.update(self.user_keys)
        with open(key_mapping_file_path, 'w') as key_mapping_file:
            json.dump(existing_data, key_mapping_file)

        for path in [self.folder_path, self.hash_path, en_i_path, en_a_path]:
            if not os.path.exists(path):
                os.makedirs(path)

        custom_key_bytes = self.user_pin.encode()
        if len(custom_key_bytes) < 16:
            custom_key_bytes += b'\x00' * (16 - len(custom_key_bytes))
        elif len(custom_key_bytes) > 16:
            custom_key_bytes = custom_key_bytes[:16]

        face_folder_path = '/home/drishti/Desktop/review2/sem8_review/db'
        voice_folder_path = '/home/drishti/Desktop/review2/sem8_review/pkl_files'
        image_pickle_file_path = os.path.join(face_folder_path, self.user_name + '.pickle')
        audio_pickle_file_path = os.path.join(voice_folder_path, self.user_name + '.pkl')

        with open(image_pickle_file_path, "rb") as image_pickle_file:
            image_data = image_pickle_file.read()

        with open(audio_pickle_file_path, "rb") as audio_pickle_file:
            audio_data = audio_pickle_file.read()

        image_data = image_data.ljust(len(image_data) + (16 - len(image_data) % 16) % 16, b'\x00')
        audio_data = audio_data.ljust(len(audio_data) + (16 - len(audio_data) % 16) % 16, b'\x00')

        # Encrypt the image and audio data separately
        encrypted_image_data = self.aes_encrypt(image_data, custom_key_bytes)
        encrypted_audio_data = self.aes_encrypt(audio_data, custom_key_bytes)

        encrypted_image_pickle_file_path = os.path.join(en_i_path, 'en_i_' + self.user_name + '.pickle')
        with open(encrypted_image_pickle_file_path, "wb") as encrypted_image_pickle_file:
            encrypted_image_pickle_file.write(encrypted_image_data)

        # Save the encrypted audio pickle file
        encrypted_audio_pickle_file_path = os.path.join(en_a_path, 'en_a_' + self.user_name + '.pkl')
        with open(encrypted_audio_pickle_file_path, "wb") as encrypted_audio_pickle_file:
            encrypted_audio_pickle_file.write(encrypted_audio_data)

        concatenated_data = encrypted_image_data + encrypted_audio_data

        # Calculate the hash (SHA-256) of the concatenated data
        hash_value = self.calculate_sha256(concatenated_data)

        reg_hash = {hash_value: self.user_name}

        # Convert the dictionary to JSON format
        reg_mapping_file_path = self.folder_path + '/reg_mapping.json'

        if os.path.exists(reg_mapping_file_path):
            # If the file exists, load existing data
            with open(reg_mapping_file_path, 'r') as reg_mapping_file:
                existing_data = json.load(reg_mapping_file)
        else:
            # If the file doesn't exist, create an empty dictionary
            existing_data = {}

        # Update existing data with the new entry
        existing_data.update(reg_hash)

        # Save the updated data to the JSON file
        with open(reg_mapping_file_path, 'w') as reg_mapping_file:
            json.dump(existing_data, reg_mapping_file)

        util.msg_box("Connect Card Reader", "Connect card reader and place card on it")
        time.sleep(5)
        r = readers()
        # print("Available readers:", r)
        reader = r[0]
        connection = reader.createConnection()
        connection.connect()
        apdu_command = [0xFF, 0xCA, 0x00, 0x00, 0x00]  # Select command
        response, sw1, sw2 = connection.transmit(apdu_command)
        # print(sw1, sw2)
        if sw1 == 0x90 and sw2 == 0x00:
            uid = toHexString(response)
            # print(uid)
            user_hash = {uid: hash_value}

            # Convert the dictionary to JSON format
            hash_mapping_file_path = self.folder_path + '/hash_mapping.json'

            # Check if the JSON file already exists
            if os.path.exists(hash_mapping_file_path):
                # If the file exists, load existing data
                with open(hash_mapping_file_path, 'r') as hash_mapping_file:
                    existing_data = json.load(hash_mapping_file)
            else:
                # If the file doesn't exist, create an empty dictionary
                existing_data = {}

            # Update existing data with the new entry
            existing_data.update(user_hash)

            # Save the updated data to the JSON file
            with open(hash_mapping_file_path, 'w') as hash_mapping_file:
                json.dump(existing_data, hash_mapping_file)
            messagebox.showinfo("Success", "Data stored successfully in card.")
            self.access = True
            # print("Response:", toHexString(response))
        else:
            messagebox.showerror("Failure", "Failed to store data in card. Response:{}".format(toHexString(response)))
            self.access = False
        connection.disconnect()

    def submit_pd(self):
        if self.is_pd == 1 and self.is_face == 1 and self.is_voice == 1:
            self.card_details()
            if self.access:
                self.response = messagebox.showinfo('Submitted', 'Your have registered successfully!')
        else:
            messagebox.showwarning("Error", "Please fill out incomplete details")
        if self.response == 'ok':
            self.root.destroy()

    def validate_pd(self, name, empid, dob, pin):
        self.user_name = name.get()
        self.user_empid = empid.get()
        self.user_dob = dob.get()
        self.user_pin = pin.get()
        self.face_file_name = ''
        if len(self.user_name) == 0 or len(self.user_empid) == 0 or len(self.user_dob) == 0 or len(self.user_pin) == 0:
            messagebox.showwarning('Error', 'Please fill out the data')
        else:
            self.is_pd = 1
            top1.destroy()

    def personal_details(self):
        if self.is_pd == 0:
            global top1
            top1 = Toplevel()
            top1.title('Personal Details')
            top1.geometry("520x350")
            top1.configure(background="#d9e3f8")

            label_name = tb.Label(top1, text='Name: ', bootstyle="bg", font=("Helvetica", 18))
            label_name.grid(row=0, column=0, padx=20, pady=20)
            global placeholder_name, entry_name, name
            name = StringVar()
            entry_name = tb.Entry(top1, textvariable=name, font=("Helvetica", 18))
            entry_name.grid(row=0, column=1, padx=20)

            label_empid = tb.Label(top1, text='Employee ID: ', bootstyle="bg", font=("Helvetica", 18))
            label_empid.grid(row=1, column=0, padx=20, pady=20)
            global placeholder_empid, entry_empid, empid
            empid = StringVar()
            entry_empid = tb.Entry(top1, textvariable=empid, font=("Helvetica", 18))
            entry_empid.grid(row=1, column=1, padx=20)

            label_dob = tb.Label(top1, text='Date of Birth: ', bootstyle="bg", font=("Helvetica", 18))
            label_dob.grid(row=2, column=0, padx=20, pady=20)
            global placeholder_dob, entry_dob, dob
            dob = StringVar()
            entry_dob = tb.Entry(top1, textvariable=dob, font=("Helvetica", 18))
            entry_dob.grid(row=2, column=1, padx=20)

            label_pin = tb.Label(top1, text='PIN: ', bootstyle="bg", font=("Helvetica", 18))
            label_pin.grid(row=3, column=0, padx=20, pady=20)
            global entry_pin, placeholder_pin, pin
            pin = StringVar()
            entry_pin = tb.Entry(top1, textvariable=pin, font=("Helvetica", 18), show='*')
            entry_pin.grid(row=3, column=1)

            button_submit = tb.Button(top1, text='Submit', bootstyle="success",
                                      command=lambda: self.validate_pd(name, empid, dob, pin))
            button_submit.grid(row=4, column=1)
        else:
            messagebox.showwarning("Error", "You have already filled out these details once")

    def add_webcam(self, label):
        if 'cap' not in self.__dict__:
            self.cap = cv2.VideoCapture(0)

        self._label = label
        self.process_webcam()

    def process_webcam(self):
        ret, frame = self.cap.read()

        self.most_recent_capture_arr = frame
        img_ = cv2.cvtColor(self.most_recent_capture_arr, cv2.COLOR_BGR2RGB)
        self.most_recent_capture_pil = Image.fromarray(img_)
        imgtk = ImageTk.PhotoImage(image=self.most_recent_capture_pil)
        self._label.imgtk = imgtk
        self._label.configure(image=imgtk)

        self._label.after(20, self.process_webcam)

    def face(self):
        if self.is_pd == 1 and self.is_face == 0:

            self.top2 = Toplevel()
            self.top2.title('Face')
            self.top2.geometry("1000x520+350+100")
            self.top2.configure(background="#d9e3f8")

            webcam_label = util.get_img_label(self.top2)
            webcam_label.place(x=10, y=0, width=700, height=500)

            self.add_webcam(webcam_label)

            # frame2 = Frame(top2, background='lightgreen', padx=175, pady=100)
            # frame2.grid(row=0, column=0, columnspan=3, padx=20, pady=20)
            # Label(frame2, text="Face").grid()

            self.login_button_main_window = tb.Button(self.top2, text='Capture Image', style="primary.TButton",
                                                      command=self.register_new_user, width=18)
            self.login_button_main_window.place(x=725, y=175)

            self.register_new_user_button_main_window = tb.Button(self.top2, text='Submit', style="success.TButton",
                                                                  command=self.close_cam, width=18)
            self.register_new_user_button_main_window.place(x=725, y=275)

        elif self.is_pd == 0:
            messagebox.showwarning("Error", "Please enter your Personal Details")

        elif self.is_face != 0:
            messagebox.showwarning("Error", "You have already filled out these details once")

    def close_cam(self):
        if len(self.face_file_name) != 0:
            self.is_face = 1
        else:
            messagebox.showwarning("Error", "Please capture the image")
            self.register_new_user_window.destroy()
        self.cap.release()
        self.top2.destroy()

    def register_new_user(self):
        self.register_new_user_window = Toplevel(self.top2)
        self.register_new_user_window.geometry("1000x520+370+120")
        self.register_new_user_window.configure(background="#d9e3f8")

        self.accept_button_register_new_user_window = tb.Button(self.register_new_user_window, text='Accept',
                                                                style="success.TButton", width=18,
                                                                command=self.accept_register_new_user)
        self.accept_button_register_new_user_window.place(x=725, y=175)

        self.try_again_button_register_new_user_window = tb.Button(self.register_new_user_window, text='Try again',
                                                                   style="danger.TButton", width=18,
                                                                   command=self.try_again_register_new_user)
        self.try_again_button_register_new_user_window.place(x=725, y=275)

        self.capture_label = util.get_img_label(self.register_new_user_window)
        self.capture_label.place(x=10, y=0, width=700, height=500)

        self.add_img_to_label(self.capture_label)

    def add_img_to_label(self, label):
        imgtk = ImageTk.PhotoImage(image=self.most_recent_capture_pil)
        label.imgtk = imgtk
        label.configure(image=imgtk)

        self.register_new_user_capture = self.most_recent_capture_arr.copy()

    def try_again_register_new_user(self):
        self.register_new_user_window.destroy()

    def accept_register_new_user(self):

        try:
            embeddings = face_recognition.face_encodings(self.register_new_user_capture)[0]

            self.face_file_name = self.user_name
            file = open(os.path.join(self.db_dir, '{}.pickle'.format(self.face_file_name)), 'wb')
            pickle.dump(embeddings, file)

            util.msg_box('Success!', 'Your image is captured successfully !')
        except:
            messagebox.showwarning("Error", "Oops!! Some error occurred, please try again")

        self.register_new_user_window.destroy()

    def voice(self):
        if self.is_face == 1 and self.is_voice == 0:
            self.top3 = Toplevel()
            self.top3.title('Voice')
            self.top3.geometry("1100x300")
            self.top3.configure(background="#d9e3f8")

            label3 = tb.Label(self.top3, text='Please say the phrase given below',
                              bootstyle="bg",
                              font=('Helvetica Bold', 16))
            label3.pack(padx=20, pady=15)

            self.label_phrase = tb.Label(self.top3, text=self.random_phrase, bootstyle="bg",
                                         font=('Helvetica Bold', 18))
            self.label_phrase.pack(pady=20, padx=20)

            button_record = tb.Button(self.top3, text='Record', command=self.record_voice, style="primary.TButton",
                                      width=18)
            button_record.pack(pady=20, padx=20)

            button_submit = tb.Button(self.top3, text='Submit', command=self.verify_voice, style="success.TButton",
                                      width=18)
            button_submit.pack(padx=20, pady=18)
        elif self.is_face == 0:
            messagebox.showwarning("Error", "Please capture your Face")

        elif self.is_voice != 0:
            messagebox.showwarning("Error", "You have already filled out these details once")

    def verify_voice(self):
        if len(self.pkl_file) != 0:
            self.is_voice = 1
        self.top3.destroy()

    def record(self, output_file, duration=5, wav_folder="wav_files", pkl_folder="pkl_files"):
        audio_data = sd.rec(int(duration * self.sampling_rate), samplerate=self.sampling_rate, channels=1,
                            dtype='int16')
        sd.wait()

        # Save the .wav file in the specified folder
        wav_path = os.path.join(wav_folder, output_file)
        sf.write(wav_path, audio_data, self.sampling_rate)
        sf.write(output_file, audio_data, self.sampling_rate)
        print(f"Recording saved to {wav_path}")

        # Convert the .wav file to a pickle file and save it in the pkl_files folder
        self.pkl_file = os.path.join(pkl_folder, os.path.splitext(output_file)[0] + ".pkl")
        self.wav_to_pkl(wav_path, self.pkl_file)
        print(f"Pickle file saved to {self.pkl_file}")

    def wav_to_pkl(self, wav_file, pkl_file):
        # Load the audio data from the .wav file
        audio_data, _ = librosa.load(wav_file, sr=self.sr)
        # Compute the MFCCs for the audio data
        mfcc = librosa.feature.mfcc(y=audio_data, sr=self.sr, n_mfcc=self.n_mfcc, n_fft=self.n_fft,
                                    hop_length=self.hop_length)

        # Save the MFCCs as a pickle file
        with open(pkl_file, "wb") as f:
            pickle.dump(mfcc, f)

    def record_voice(self):
        wav_file = self.user_name + ".wav"
        self.record(wav_file)

    def start(self):
        self.root.mainloop()


if __name__ == "__main__":
    app = App()
    app.start()
